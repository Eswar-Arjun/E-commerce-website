# E-Commerce-website-using-html-css-Js
  A simulation of client side e-commerce website with feature as add to cart, proceed for checkout and payment options. It simultes a shopping cart within a website.

Follow the following steps to view the project:
1. Download the folder web1 using clone or download option on the right of the repository.
                                     OR
   Create a folder in your laptop preferably on Desktop and then download the files inside the folder.
   
2. Once you are done with downloads please note that the names of files and images as well as the image folder must be same as the uploaded files in the repository since they have been used inside the codes with their paths.

Now you are all set to view the project.

3. open "index.html" file with your browser(any).
4. For further simulation you will we instructed in the web page such as add to cart will take to "your cart" and then you can choose the more options on cart page.

5. Further you can proceed for checkout fill all your details in proper format such as mail id should be formatted as "id@gmail.com" etc.




I will further attach the screenshots of the webpage in screenshots folder.

Here is a similar but cleaner version of this project
[E-COMMERCE-STORE](https://github.com/vinita2000/E-Commerce-Website)
